 <!--
                        <div class="form-group">
                            <label for="level">Jabatan</label>
                            <input type="hidden" name="id_user" id="idjson">
                            <select class="form-control form-control-sm" name="jabatan" id="jabatan" required>
                            <option value="">- Pilih Jabatan -</option>
                                <option value="BOD">BOD</option>
                                <option value="Deputy Director">Deputy Director</option>
                                <option value="Division Head">Division Head</option>
                                <option value="Manager">Manager</option>
                                <option value="Yunior Manager">Yunior Manager</option>
                                <option value="Supervisor">Supervisor</option>
                                <option value="BS Manager">BS Manager</option>
                                <option value="Account Manager">Account Manager</option>
                                <option value="Yunior Account Manager">Yunior Account Manager </option>
                                <option value="PMO">PMO</option>
                                <option value="Staff">Staff</option>
                            </select>
                        </div> -->