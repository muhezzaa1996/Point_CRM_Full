<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?php echo $title; ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
                    <?php echo $this->session->flashdata('msg'); ?>
                    <?php if (validation_errors()) { ?>
                        <div class="alert alert-danger">
                            <strong><?php echo strip_tags(validation_errors()); ?></strong>
                            <a href="" class="float-right text-decoration-none" data-dismiss="alert"><i class="fas fa-times"></i></a>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <div class="card card-primary card-outline">
                <div class="card">
                    <div class="card-header">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#add-user">
                            Tambah Project
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class=" table table-bordered table-hover" id="table-data" style="font-size:14px;">
                                <thead>
                                <th>#</th>
                                    <th># Job</th>
                                    <th>Nama Project</th>
                                    <th>Customer</th>
                                    <th>Rp. Nominal</th>
                                    <th>Peluang</th>
                                    <th>Sales</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($project as $lu) : ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $lu['no_job']; ?></td>
                                            <td><?php echo $lu['nama_project']; ?></td>
                                            <td><?php echo $lu['customer']; ?> Kg</td>
                                            <td>Rp. <?php echo rupiah($lu['nilai_project']); ?></td>
                                            <td><?php echo $lu['peluang'];?> %</td>
                                            <td><?php echo $lu['sales1']; ?></td>
                                            <td><?php echo $lu['keterangan']; ?></td>
                                            <td><button class="tombol-edit btn btn-info btn-block btn-sm" data-id="<?php echo $lu['id_project']; ?>" data-toggle="modal" data-target="#edit-user">Edit</button></td>
                                            <td><a href="<?php echo base_url('admin/del_project/') . $lu['id_project']; ?>" class="tombol-hapus btn btn-danger btn-block btn-sm">Hapus</a> </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<!-- Modal -->
<div class="modal fade" id="add-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Project</h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <form action="<?php echo base_url('admin/pra_project'); ?>" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tgl. Pra Project</label>
                                    <input type="date" class="form-control form-control-sm" name="tgl_project" required>
                                </div>
                            </div>   
                            <div class="col-md-6"> 
                                <div class="form-group"> 
                                    <label> Nomor Job </label>
                                    <input type="text" class="form-control form-control-sm" name="no_job" required>
                                </div>
                            </div>    
                        </div>    
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Customer </label>
                                    <input type="text" class="form-control form-control-sm" name="customer" required>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label>Nama Project </label>
                                    <input type="text" class="form-control form-control-sm" name="nama_project" required>
                                </div>
                            </div>    
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nilai Project </label>
                                    <input type="number" class="form-control form-control-sm" name="nilai_project" required>
                                </div>
                            </div>
                            <div class="col-md-6">                                                    
                                <div class="form-group">
                                    <label>Peluang % </label>
                                    <input type="number" class="form-control form-control-sm" name="peluang" required>
                                </div>
                            </div>    
                        </div>    
                        <div class="row">
                            <div class="col-md-6">            
                                <div class="form-group">
                                    <label>Sales 1 / PIC </label>
                                    <input type="text" class="form-control form-control-sm" name="sales1" required>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label>Sales 2 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales2" required>
                                </div>
                            </div>    
                        </div>    
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Sales 3  </label>
                                    <input type="text" class="form-control form-control-sm" name="sales3" required>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label>Sales 4 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales4" required>
                                </div>
                            </div>    
                        </div>
                        <div class="row">   
                            <div class="col-md-6"> 
                                <div class="form-group">
                                    <label>Keterangan Project </label>
                                    <input type="text" class="form-control form-control-sm" name="keterangan" required>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label>Tgl. Update Project </label>
                                    <input type="date" class="form-control form-control-sm" name="tgl_update" required>
                                </div>
                            </div>    
                        </div>    

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary pull-right">Simpan Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>

<div class="modal fade" id="edit-user">
    <div class="modal-dialog" >
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Edit project </h4>
            </div>
            <div class="modal-body">
                <div class="box-body">
                    <form action="<?php echo base_url('admin/edit_project'); ?>" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Tgl. Input </label>
                                    <input type="text" clas="form-control form-control-sm" name="id_project" id="id_project" hidden>
                                    <input type="date" class="form-control form-control-sm" name="tgl_project" id="tgl_project" required>
                                </div>
                            </div>
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label> Nomor Job </label>
                                    <input type="text" class="form-control form-control-sm" name="no_job" id="no_job" readonly>
                                </div>            
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Customer </label>
                                    <input type="text" class="form-control form-control-sm" name="customer" id="customer" requeird>
                                </div>
                            </div>    
                            <div class="col-md-6">    
                                <div class="form-group">
                                    <label>Nama Project </label>
                                    <input type="text" class="form-control form-control-sm" name="nama_project" id="nama_project" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Nilai Project </label>
                                    <input type="number" class="form-control form-control-sm" name="nilai_project" id="nilai_project" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> % Peluang </label>
                                    <input type="number" class="form-control form-control-sm" name="peluang" id="peluang" requrired>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Sales 1 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales1" id="sales1" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Sales 2 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales2" id="sales2" required>
                                </div>
                            </div>
                        </div>                
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Sales 3 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales3" id="sales3" requried>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label> Sales 4 </label>
                                    <input type="text" class="form-control form-control-sm" name="sales4" id="sales4" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <input type="date" class="form-control form-control-sm" name="tgl_update" id="tgl_update" hidden>
                                    <input type="text" class="form-control form-control-sm" name="keterangan" id="keterangan" requried>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary pull-right">Simpan Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
</div>

<script>
    $('.tombol-edit').on('click', function() {
        const id_project = $(this).data('id');
        $.ajax({
            url: '<?php echo base_url('admin/get_project'); ?>',
            data: {
                id_project: id_project
            },
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#tgl_project').val(data.tgl_project);
                $('#no_job').val(data.no_job);
                $('#id_project').val(data.id_project);
                $('#customer').val(data.customer);
                $('#nama_project').val(data.nama_project);
                $('#nilai_project').val(data.nilai_project);
                $('#peluang').val(data.peluang);
                $('#sales1').val(data.sales1);
                $('#sales2').val(data.sales2);
                $('#sales3').val(data.sales3);
                $('#sales4').val(data.sales4);
                $('#keterangan').val(data.keterangan);
                $('#tgl_update').val(date);
            }
        });
    });
</script>